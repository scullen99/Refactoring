package combate;

import personajes.Personaje;

public interface InterfazCombate
{
	public void combate(Personaje atacante, Personaje defensor);
}
