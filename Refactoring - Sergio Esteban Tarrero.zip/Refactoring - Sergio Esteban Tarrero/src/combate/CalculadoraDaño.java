package combate;

import personajes.Personaje;
import java.util.concurrent.ThreadLocalRandom; // libreria generar numeros aleatorios

public class CalculadoraDa�o
{
	// refactorizaci�n extracci�n de m�todo
	public int calcularDa�o(Personaje atacante, Personaje defensor)
	{
		int da�o = atacante.getAtaque() - defensor.getDefensa();
		
		if(da�o < 0)
			da�o = 0;
		
		return da�o;
	}
	
	private boolean calcularProbabilidadEstado(int probabilidad) 
	{
		int randomNum = ThreadLocalRandom.current().nextInt(0, 100);
		
		if(randomNum >= probabilidad)

			return true;
		
		return false;
	}
	
	public boolean ardiendo()
	{
		return this.calcularProbabilidadEstado(15);
	}
	
	public boolean congelado()
	{
		return this.calcularProbabilidadEstado(10);
	}
	
	public boolean desorientado()
	{
		return this.calcularProbabilidadEstado(25);
	}
	
	public boolean sangrado()
	{
		return this.calcularProbabilidadEstado(20);
	}
	
	public boolean envenenado()
	{
		return this.calcularProbabilidadEstado(15);
	}
	
}
