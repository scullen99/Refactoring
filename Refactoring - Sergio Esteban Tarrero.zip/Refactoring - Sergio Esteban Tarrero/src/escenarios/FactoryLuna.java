package escenarios;

import enemigos.Homeopata;
import enemigos.Oso;
import enemigos.Terraplanista;
import enemigos.Twittero;
import enemigos.Vikingo;

public class FactoryLuna implements AbstractFactoryEnemigos {

	public Homeopata getHomeopata() { return new Homeopata("Homeopata en la Luna", 10, 4, 100); }
   
	public Oso getOso() { return new Oso("Oso Lunoso", 8, 12, 110); }

	public Terraplanista getTerraplanista() { return new Terraplanista("Terraplanista en la Luna", 2, 2, 10); }
  
	public Twittero getTwittero() { return new Twittero("Twittero en la Luna", 2, 10, 100); }

	public Vikingo getVikingo() { return new Vikingo("Vikingo en la Luna", 14, 20, 100); }
}