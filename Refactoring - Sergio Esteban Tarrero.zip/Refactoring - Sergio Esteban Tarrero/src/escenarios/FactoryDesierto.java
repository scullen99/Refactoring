package escenarios;

import enemigos.Homeopata;
import enemigos.Oso;
import enemigos.Terraplanista;
import enemigos.Twittero;
import enemigos.Vikingo;

public class FactoryDesierto implements AbstractFactoryEnemigos
{
	public Homeopata getHomeopata() { return new Homeopata("Homeopata en el desierto", 8, 3, 90); }
	
	public Oso getOso() { return new Oso("Oso Caluroso", 8, 12, 100); }
		 
	public Terraplanista getTerraplanista() { return new Terraplanista("Terraplanista en el desierto", 6, 15, 100); }

	public Twittero getTwittero() { return new Twittero("Twittero en el desierto", 6, 8, 90); }

	public Vikingo getVikingo() { return new Vikingo("Vikingo en el desierto", 10, 8, 100); }
}