package escenarios;

import enemigos.Homeopata;
import enemigos.Oso;
import enemigos.Terraplanista;
import enemigos.Twittero;
import enemigos.Vikingo;

public class FactoryMercadona implements AbstractFactoryEnemigos
{
		public Homeopata getHomeopata() { return new Homeopata("Homeopata en el Mercadona", 8, 6, 100); }
 
		public Oso getOso() { return new Oso("Oso gastoso", 6, 12, 120); }

	    public Terraplanista getTerraplanista() { return new Terraplanista("Terraplanista en el Mercadona", 4, 10, 100); }

	    public Twittero getTwittero() { return new Twittero("Twittero en el Mercadona", 8, 8, 90); }

		public Vikingo getVikingo() { return new Vikingo("Vikingo en el Mercadona", 20, 15, 200); }
}