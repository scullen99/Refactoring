package enemigos;

import combate.CalculadoraDa�o;
import estado.EstadoSangrando;
import personajes.Jugador;
import personajes.Personaje;

public class Oso extends Enemigo
{
	public Oso(String nombre, int ataque, int defensa, int vidaMaxima)
	{
		super(nombre, ataque, defensa, vidaMaxima, "Hibernacion levitante", "Zarpazo");
	}

	public void usarHabilidadPrimaria()
	{
		System.out.println(this.getNombre() + " hibern� 8 horas y se cur� 10hp");
        this.curar(10);
	}


	public void usarHabilidadSecundaria(Jugador objetivo)
	{
		CalculadoraDa�o probabilidadEstado = new CalculadoraDa�o();
		
		if(probabilidadEstado.sangrado())
		{
			System.out.println(this.getNombre() + " hace sangrar a " + objetivo.getNombre());
			objetivo.a�adirEstado(new EstadoSangrando(objetivo));		
		}
		
		else
			System.out.println(this.getNombre() + " hizo un mal movimiento y lo esquivaste!");
	}


	public void atacar(Jugador objetivo)
	{
        System.out.println("Oso: Te meto un zarpazo y no vuelves!");  
        this.imprimirFrasesAtaque(objetivo); 
    }
}