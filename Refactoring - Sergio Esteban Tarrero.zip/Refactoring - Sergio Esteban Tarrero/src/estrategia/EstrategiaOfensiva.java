package estrategia;

import enemigos.Enemigo;
import personajes.Jugador;
import personajes.Personaje;

public class EstrategiaOfensiva extends EstrategiaCombate
{
	public EstrategiaOfensiva(Enemigo componente)
	{
		super(componente);
	}

	public void ejecutarEstrategia(Personaje jugador)
	{
		if(jugador.estaVivo())
		{
			this.atacarJugador(jugador);
			System.out.println(this.componente.getNombre() + " va a usar " + this.componente.getnombreHabilidadSecundaria());
			this.componente.usarHabilidadSecundaria((Jugador) jugador);
		}
	}
}