package estrategia;

import enemigos.Enemigo;
import personajes.Jugador;
import personajes.Personaje;

public abstract class EstrategiaCombate
{
	protected Enemigo componente;
	
	public EstrategiaCombate(Enemigo componente)
	{
		this.componente = componente;
	}
	
	public abstract void ejecutarEstrategia(Personaje personajesJugador);
	
	protected void atacarJugador(Personaje jugador)
	{
		System.out.println(this.componente.getNombre() + " se prepara para atacar a " + jugador.getNombre());
		this.componente.atacar((Jugador) jugador);
	}
}