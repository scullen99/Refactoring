package main;

import java.util.ArrayList;
import java.util.Scanner;

import enemigos.Enemigo;
import escenarios.FactoryDesierto;
import escenarios.FactoryLuna;
import escenarios.FactoryMercadona;
import estrategia.*;
import personajes.Jugador;

public class Main
{
	public static ArrayList<Enemigo> generarCombateDesierto()
	{
		ArrayList<Enemigo> enemigos = new ArrayList<Enemigo>();
		
		FactoryDesierto fabricaDesierto = new FactoryDesierto();
		
		enemigos.add(fabricaDesierto.getOso());
		enemigos.add(fabricaDesierto.getTerraplanista());
		enemigos.add(fabricaDesierto.getTwittero());
		
		return enemigos;	
	}
	
	public static ArrayList<Enemigo> generarCombateLuna()
	{
		ArrayList<Enemigo> enemigos = new ArrayList<Enemigo>();
		
		FactoryLuna fabricaLuna = new FactoryLuna();
		
		enemigos.add(fabricaLuna.getOso());
		enemigos.add(fabricaLuna.getTerraplanista());
		enemigos.add(fabricaLuna.getTwittero());
		enemigos.add(fabricaLuna.getVikingo());
		
		return enemigos;	
	}
	
	public static ArrayList<Enemigo> generarCombateMercadona()
	{
		ArrayList<Enemigo> enemigos = new ArrayList<Enemigo>();
		
		FactoryMercadona fabricaMercadona = new FactoryMercadona();
		
		enemigos.add(fabricaMercadona.getOso());
		enemigos.add(fabricaMercadona.getTerraplanista());
		enemigos.add(fabricaMercadona.getTwittero());
		enemigos.add(fabricaMercadona.getHomeopata());
		enemigos.add(fabricaMercadona.getVikingo());
		
		return enemigos;	
	}
	
	public void ejecutarCombate(Jugador jugador, ArrayList<Enemigo> enemigos) 
	{
		Scanner inputTeclado = new Scanner(System.in);
		
		while((!enemigos.isEmpty()) && (jugador.estaVivo()))
		{
			
			System.out.println("Turno de " + jugador.getNombre() + " vs " + enemigos.get(0).getNombre());
			
			if(jugador.getCongelado()) 
				System.out.println(jugador.getNombre() + " est� congelado! Pierde su turno");
			
			else
			{
				System.out.println("\n�Qu� quieres hacer?");
				System.out.println("1. Atacar");
				System.out.println("2. Curarse");
				System.out.println("3. No hacer nada");
				
				switch(inputTeclado.nextInt())
				{
				
				case 1:
					System.out.println("\n" + jugador.getNombre() + " se dispone a atacar a " + enemigos.get(0).getNombre());
					jugador.atacar(enemigos.get(0));
					
					break;
					
				case 2:
					System.out.println(jugador.getNombre() + " se cura 20 hp \n");
					jugador.curar(20);
					break;
					
				case 3:
					System.out.println(jugador.getNombre() + " se queda mirando ... \n");
					break;
					
				default:
					System.out.println("Opci�n introducida no v�lido. Se salta turno \n");
				}
				
				jugador.ejecutarEstados();
			}
			
			if(!enemigos.get(0).estaVivo())
			{
				System.out.println(jugador.getNombre() + " ha matado a " + enemigos.get(0).getNombre() + "\n");
				enemigos.remove(0);
				
			} 
			
			else
			{

				if(!enemigos.isEmpty())
				{
					EstrategiaCombate estrategia = null;
					
					if(enemigos.get(0).getVida() < enemigos.get(0).getVidaMaxima() / 2)
						estrategia = new EstrategiaDefensiva(enemigos.get(0));
				
					else
					{
						estrategia = new EstrategiaOfensiva(enemigos.get(0));
					}
					
					enemigos.get(0).ejecutar(estrategia, jugador);
					
				}
			}
		
		}
		
	}
	
	public static void main(String []args)
	{
		Main main = new Main();
		
		ArrayList<Enemigo> enemigos = new ArrayList<Enemigo>();	
		
		Scanner inputTeclado = new Scanner(System.in);
		
		System.out.println("Escribe el nombre del jugador: ");
		String nombreJugador = inputTeclado.next();		
		System.out.println("Escribe el Ataque de " + nombreJugador + ":");
		int ataquePJ = inputTeclado.nextInt();		
		System.out.println("Escribe la Defensa de " + nombreJugador + ":");
		int defensaPJ = inputTeclado.nextInt();		
		System.out.println("Escribe la vida de " + nombreJugador + ":");
		int vidaPJ = inputTeclado.nextInt();
		
		Jugador jugador = new Jugador(nombreJugador, ataquePJ, defensaPJ, vidaPJ);
				
		System.out.println("\nStats de personaje: ");
		System.out.println("Nombre: " + jugador.getNombre());
		System.out.println("Ataque: " + ataquePJ);
		System.out.println("Defensa: " + defensaPJ);
		System.out.println("Vida: " + vidaPJ);
		System.out.println(" ");
			
		enemigos.addAll(generarCombateDesierto());			
		main.ejecutarCombate(jugador, enemigos);
		
		if(!jugador.estaVivo())	
			System.out.println("\nSe termin� el juego. :( ");
		
		else
		{
			System.out.println("\nLa siguiente fase es en la Luna, Adelante!\n");
			enemigos.addAll(generarCombateLuna());		
			main.ejecutarCombate(jugador, enemigos);
			
			if(jugador.estaVivo() != true)
				System.out.println("Se termin� el juego. \n");
				
			else
			{
				System.out.println("La siguiente fase es en Mercadona porque te falta el papel higienico, Adelante! \n");
				enemigos.addAll(generarCombateMercadona());
				main.ejecutarCombate(jugador, enemigos);
				
				if(jugador.estaVivo() != true) 
					System.out.println("Se termin� el juego :(");
				
				else
				{
					System.out.println("\nGANASTE EL JUEGO ERES UNA BESTIA!!!!!");
					System.out.println("\n\nRefactorizaci�n realizada por: ");
					System.out.println("Sergio Esteban Tarrero");
				}
			}
		}
		inputTeclado.close();
	}
}